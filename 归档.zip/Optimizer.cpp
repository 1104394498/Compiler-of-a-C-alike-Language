#include "Optimizer.h"

void Optimizer::optimize() {
    // not implemented yet
    // should ensure that a[1] = b[1] ==> t1 = b[1]; a[1] = t1;
}
